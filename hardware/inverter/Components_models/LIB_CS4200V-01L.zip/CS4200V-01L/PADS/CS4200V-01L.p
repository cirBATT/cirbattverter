*PADS-LIBRARY-PART-TYPES-V9*

CS4200V-01L CS4200V01L I XFR 9 1 0 0 0
TIMESTAMP 2026.08.08.13.19.21
"Manufacturer_Name" COILCRAFT
"Manufacturer_Part_Number" CS4200V-01L
"Mouser Part Number" 994-CS4200V-01L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Coilcraft/CS4200V-01L?qs=ZYnrCdKdyefaFHHi0DBZHg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" TRANSFORMER, CURRENT SENSE, 1:200, 35A
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/CS4200V-01L.pdf
"Geometry.Height" 19.05mm
GATE 1 4 0
CS4200V-01L
1 0 U SEC_(N_TURNS)_1
2 0 U PRI_(1_TURN)_1
3 0 U PRI_(1_TURN)_2
4 0 U SEC_(N_TURNS)_2

*END*
*REMARK* SamacSys ECAD Model
292589/1222751/2.50/4/4/Transformer
