*PADS-LIBRARY-PART-TYPES-V9*

CMI-1271-85-SMT-TR CMI127185SMTTR I ANA 9 1 0 0 0
TIMESTAMP 2026.08.08.21.05.50
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" CMI-1271-85-SMT-TR
"Mouser Part Number" 490-CMI-1271-85SMTTR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/CMI-1271-85-SMT-TR?qs=P1JMDcb91o5n%252BOcidK0K5Q%3D%3D
"Arrow Part Number" CMI-1271-85-SMT-TR
"Arrow Price/Stock" https://www.arrow.com/en/products/cmi-1271-85-smt-tr/cui-devices?region=nac
"Description" 12.8 mm, 12 Vdc, 85 dB, Surface Mount (SMT), Driving Circuit, Magnetic Audio Indicator Buzzer
"Datasheet Link" https://www.sameskydevices.com/product/resource/cmi-1271-85-smt-tr.pdf
"Geometry.Height" 7.6mm
GATE 1 2 0
CMI-1271-85-SMT-TR
2 0 U +
1 0 U -

*END*
*REMARK* SamacSys ECAD Model
11522836/1222751/2.50/2/2/Loudspeaker or Buzzer
